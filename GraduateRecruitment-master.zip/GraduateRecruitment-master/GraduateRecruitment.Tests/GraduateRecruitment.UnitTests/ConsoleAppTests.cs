﻿using System;
using System.Collections.Generic;
using FluentAssertions;
using FluentAssertions.Execution;
using NUnit.Framework;

namespace GraduateRecruitment.UnitTests
{
    [TestFixture]
    public class ConsoleAppTests
    {
    }
}