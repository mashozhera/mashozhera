﻿namespace GraduateRecruitment.ConsoleApp.Data.Entities
{
    internal class InventoryDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
    }
}