﻿namespace GraduateRecruitment.ConsoleApp.Data.Models
{
    internal class Quantity
    {
        public int Taken { get; set; }
        public int Added { get; set; }
    }
}