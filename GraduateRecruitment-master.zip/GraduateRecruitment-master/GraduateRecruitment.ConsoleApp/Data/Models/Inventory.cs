﻿namespace GraduateRecruitment.ConsoleApp.Data.Models
{
    internal class Inventory
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
    }
}